function confirmacion(){
    return confirm("¿Seguro que quieres borrarlo?") ;
}

function confirmacionPublish(){
    return confirm("¿Seguro que quieres publicarlo (o dejar de publicarlo)?") ;
}